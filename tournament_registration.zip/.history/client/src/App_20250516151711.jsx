//import { useState } from 'react'
//import reactLogo from './assets/react.svg'
//import viteLogo from '/vite.svg'
import './App.css'

export default function App() {
  
  return (
    <>
      <div>
       <h1>Welcome to Frontend</h1>
      </div>
      
    </>
  )
}

export default App
